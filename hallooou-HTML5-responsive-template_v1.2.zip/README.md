# Hallooou - One page HTML5 responsive template

Hallooou is multi-purpose, creative, one page parallax, responsive theme for portfolio showcase, modern businesses, agency, personal use, etc.

Key Features:

	•	One Page
	•	Built with Bootstrap 3
	•	Retina Ready
	•	Clean & Minimal Design
	•	Unique navigation
	•	Fully Responsive & Mobile-Friendly Design
	•	Parallax Effect
	•	Font Awesome Icons
	•	Google Fonts
	•	Google Maps
	•	YouTube Video Background
	•	HTML5 Video Background
	•	Ajax Contact Form with validation
	•	4 Premade color Options


[Live Demo](http://bit.ly/ht_preview)

Note: Images used in the theme are for preview purpose only.


-	Author:	Mauritius D'Silva
-	URL:	www.mauritiusdsilva.com
